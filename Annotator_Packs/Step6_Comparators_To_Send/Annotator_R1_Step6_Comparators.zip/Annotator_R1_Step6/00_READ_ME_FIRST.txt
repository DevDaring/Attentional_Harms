HUMAN LABELLING PACKAGE - Step 6 (rater R1)
Identity Information in Assistant Responses

This package is complete: everything you need for Step 6 is inside.

Files, in the order to use them:
  1. Annotation_Guidelines_v1.0.docx      Same guidelines as Steps 1-5. Re-read sections on
                                          relevance (Q6) and retention (Q9) before starting.
  2. Quick_Reference_Card_v1.0.docx       Keep it open while you label.
  3. Practice_Workbook_v1.0.xlsx          13 practice items for warm-up (optional if you finished
  4. Practice_Answer_Key_v1.0.docx        Steps 1-5 recently). Open the key only after practising.
  5. Step6_Comparators_R1.xlsx            264 items to label.
  6. Work_Log_R1.xlsx                     One row per working session.

About Step 6
  Each item shows a conversation, the current request and one assistant response. Several items
  share the same request but have different responses, and some requests may look familiar from
  earlier steps. Label every item on its own, from the response in front of you. Do not look up
  your earlier answers or compare items with each other.

Workload
  264 items at about 90 seconds each is roughly 6.6 hours. Take a break about every
  45 minutes and do not label more than about 3 hours a day.

How to fill the workbook
  Use the drop-down list in each answer column (Q1-Q13). Do not edit the grey columns A-D, and do
  not add, delete or reorder rows. Keep the file name unchanged. Leave the Notes column empty
  unless an item is broken (for example, an empty or cut-off response).
  If you use Google Sheets, keep the file in one Google Sheet (version history on) and download it
  as .xlsx when you return it.

Work on your own. Do not discuss items with the other raters until all three have returned
their workbooks.

Return Step6_Comparators_R1.xlsx and Work_Log_R1.xlsx to the coordinator when finished.

Questions: Koushik Deb, Department of Computer Science & Engineering, IIIT Kalyani
E-mail: koushikdeb2009@gmail.com
